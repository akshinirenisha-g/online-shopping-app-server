# Shop Backend (Spring Boot)

Minimal Spring Boot backend for the Online Shopping Management project.

## Features
- Entities: Category, Product, User, Address, Payment, OrderStatus, Order
- CRUD REST APIs for Category, Product, Order
- Filtering products by category
- Uses Spring Data JPA + MySQL
- OpenAPI (Swagger) UI at `/swagger-ui.html` when running

## How to run
1. Update `src/main/resources/application.properties` with your MySQL credentials.
2. Create database `shopdb` in MySQL.
3. Build and run:
   ```
   mvn clean package
   mvn spring-boot:run
   ```
4. API base: `http://localhost:8080/api`

