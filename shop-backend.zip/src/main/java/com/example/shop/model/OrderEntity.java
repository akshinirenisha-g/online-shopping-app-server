package com.example.shop.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long productId;
    private Long userId;
    private LocalDateTime orderDate;

    @ManyToOne
    @JoinColumn(name = "address_id")
    private Address address;

    @ManyToOne
    @JoinColumn(name = "payment_id")
    private Payment payment;

    private Double unitPrice;
    private Integer numberOfItems;
    private Double offer;
    private Double deliveryCost;
    private Double totalCost;
    private LocalDateTime deliveryDate;

    @ManyToOne
    @JoinColumn(name = "status_id")
    private OrderStatus status;
}
