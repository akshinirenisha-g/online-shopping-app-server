INSERT INTO category (id, name) VALUES (1, 'Food') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO category (id, name) VALUES (2, 'Electronics') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO category (id, name) VALUES (3, 'Fashion') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO category (id, name) VALUES (4, 'Books') ON DUPLICATE KEY UPDATE name=name;

INSERT INTO order_status (id, status) VALUES (1,'Draft') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (2,'order placed') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (3,'packed') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (4,'dispatched') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (5,'on the way') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (6,'delivered') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (7,'cancelled') ON DUPLICATE KEY UPDATE status=status;
INSERT INTO order_status (id, status) VALUES (8,'returned') ON DUPLICATE KEY UPDATE status=status;
